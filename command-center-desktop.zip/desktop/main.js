// Opsis Command Center — desktop shell (Windows & Mac).
//
// This is a thin native wrapper around the existing web app. It does NOT
// re-implement anything: it opens app.opsiscx.com in a dedicated app window
// (own icon, no browser chrome) and lets the web app fire real OS
// notifications. Because it loads the hosted site, the desktop app always
// shows the latest version — no rebuild needed when the web app updates.

const { app, BrowserWindow, shell, Menu, nativeImage } = require('electron')
const path = require('path')

// Which site the app loads. Override with CC_URL for staging, e.g.
//   CC_URL=https://command-center-git-staging-opsis-cx1.vercel.app npm start
const APP_URL = process.env.CC_URL || 'https://app.opsiscx.com'

let mainWindow = null

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 680,
    title: 'Command Center',
    backgroundColor: '#0b0b0f',
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: true
    }
  })

  mainWindow.loadURL(APP_URL)

  // Keep in-app navigation inside the window; open outside links (Google,
  // Drive, etc.) in the user's real browser instead of a blank app window.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    try {
      const target = new URL(url)
      const base = new URL(APP_URL)
      if (target.host === base.host) return { action: 'allow' }
    } catch (_) { /* fall through */ }
    shell.openExternal(url)
    return { action: 'deny' }
  })

  mainWindow.on('closed', () => { mainWindow = null })
}

// A minimal, native-feeling menu (Cmd/Ctrl+R reload, zoom, copy/paste, etc.).
function buildMenu() {
  const isMac = process.platform === 'darwin'
  const template = [
    ...(isMac ? [{ role: 'appMenu' }] : []),
    { role: 'fileMenu' },
    { role: 'editMenu' },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    },
    { role: 'windowMenu' }
  ]
  Menu.setApplicationMenu(Menu.buildFromTemplate(template))
}

app.whenReady().then(() => {
  if (process.platform === 'darwin') {
    try { app.dock.setIcon(nativeImage.createFromPath(path.join(__dirname, 'build', 'icon.png'))) } catch (_) {}
  }
  buildMenu()
  createWindow()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})
